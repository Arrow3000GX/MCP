void MYMODULE(void)
{
}
