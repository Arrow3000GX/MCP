CMAKE_NOT_USING_CONFIG_FLAGS
----------------------------

Skip ``_BUILD_TYPE`` flags if true.

This is an internal flag used by the generators in CMake to tell CMake
to skip the ``_BUILD_TYPE`` flags.
