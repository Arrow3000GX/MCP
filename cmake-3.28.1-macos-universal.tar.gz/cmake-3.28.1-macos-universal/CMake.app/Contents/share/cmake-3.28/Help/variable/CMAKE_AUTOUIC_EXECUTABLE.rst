CMAKE_AUTOUIC_EXECUTABLE
------------------------

.. versionadded:: 3.27

This variable is used to initialize the :prop_tgt:`AUTOUIC_EXECUTABLE`
property on all the targets. See that target property for additional
information.

By default it is empty.
