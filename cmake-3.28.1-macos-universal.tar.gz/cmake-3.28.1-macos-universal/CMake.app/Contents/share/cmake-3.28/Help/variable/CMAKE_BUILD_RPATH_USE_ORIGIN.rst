CMAKE_BUILD_RPATH_USE_ORIGIN
----------------------------

.. versionadded:: 3.14

Whether to use relative paths for the build ``RPATH``.

This is used to initialize the :prop_tgt:`BUILD_RPATH_USE_ORIGIN` target
property for all targets, see that property for more details.
