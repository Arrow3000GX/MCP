CMAKE_<LANG>_SIZEOF_DATA_PTR
----------------------------

Size of pointer-to-data types for language ``<LANG>``.

This holds the size (in bytes) of pointer-to-data types in the target
platform ABI.  It is defined for languages ``C`` and ``CXX`` (C++).
